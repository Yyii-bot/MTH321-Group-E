# 交付验证记录

本交付仅覆盖 Algorithm Implementation。

- `python -m pytest -q`：55 项测试通过，包含模型/Jacobian、独立参考对照、收敛阶、Newton失败、拒步计数、参考文件校验和压缩记录导出。
- 完整 `python code/run_all.py`：32 个实验，29 个到达终点，3 个数值失败算例如实保留。
- EE/IE matched-error 配对达到配置的 1.15 误差比范围。
- 400 个正时间点的 eigenanalysis 全部有效，并与 reduced Jacobian 交叉核对。
- 13 组图已检查，分别提供 PNG 与 PDF；所有 CSV 行有对应运行参数和 NPZ 数据。
- 图表与数据均标为 DEVELOPMENT ONLY；最终应接入团队确认的 reference 重跑。

完整实验耗时与依赖版本以 `results/development/manifest.json` 为准。失败 stress case 不等于测试失败：它们用于展示大步长/松 tolerance 下方法的限制。

仓库不包含课程原始教材、虚拟环境或本机专用路径。长历史采用 NPZ 压缩，适合逐文件上传 GitHub。ZIP 解压后，上传项目文件夹里的内容即可。
