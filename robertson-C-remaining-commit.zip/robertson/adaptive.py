"""Adaptive RK4 and Implicit Euler using step doubling.

The accepted state is the result of two half steps, without Richardson
extrapolation. The error estimate is absolute infinity norm, divided by
``2**p - 1``; ``tol`` is a local error budget, not a global error guarantee.
"""

from time import perf_counter

import numpy as np

from .solvers import _validate_inputs, _make_stats, _step, _state_failure, _note_negativity


def solve_adaptive(method, t0, tf, y0, h0, tol, options=None):
    """Return ``(t, Y, stats)`` for adaptive RK4 (p=4) or IE (p=1).

    Attempt one full step and two half steps from the same initial state.
    Accept the two-half-step state if its estimated error is <= ``tol``.
    Set ``h_new = h * safety * (tol / error)**(1/(p+1))``, limited by
    ``min_factor``/``max_factor`` and ``h_min``/``h_max``. Failed Newton or
    nonfinite trials are rejected and retried with a smaller step.

    Options extend the fixed solver options: ``h_min`` (1e-14), ``h_max``
    (the interval length), ``safety`` (0.9), ``min_factor`` (0.2),
    ``max_factor`` (5), ``max_rejected_steps`` (100000), and
    ``max_consecutive_rejections`` (50). A shorter final step is allowed
    to hit tf exactly. All RHS/Jacobian work, including failed/rejected
    trials and the coarse solution, contributes to the counters.

    ``h_history`` and ``error_history`` correspond to accepted macro steps;
    each trial appears in ``attempted_h_history`` and
    ``attempted_error_history``. Newton histories include all attempted
    base-method solves. Returned Y contains accepted macro endpoints only.
    """
    started = perf_counter()
    method = str(method).upper()
    if method not in ("RK4", "IE"):
        raise ValueError("adaptive method must be RK4 or IE")
    t0, tf, y0, h0, opts = _validate_inputs(t0, tf, y0, h0, options)
    tol = float(tol)
    if not np.isfinite(tol) or tol <= 0:
        raise ValueError("adaptive tol must be positive and finite")
    h_min = float(opts.get("h_min", 1.0e-14))
    h_max = float(opts.get("h_max", max(tf - t0, h0)))
    safety = float(opts.get("safety", 0.9))
    min_factor = float(opts.get("min_factor", 0.2))
    max_factor = float(opts.get("max_factor", 5.0))
    if not np.all(np.isfinite([h_min, h_max, safety, min_factor, max_factor])):
        raise ValueError("adaptive controller parameters must be finite")
    if not 0 < h_min <= h_max:
        raise ValueError("Require 0 < h_min <= h_max")
    if not 0 < safety < 1 or not 0 < min_factor < 1 or max_factor < 1:
        raise ValueError("Require 0<safety<1, 0<min_factor<1 and max_factor>=1")
    max_rejected = opts.get("max_rejected_steps", opts.get("max_rejections", 100_000))
    max_consecutive = opts.get("max_consecutive_rejections", 50)
    for key, value in (("max_rejected_steps", max_rejected),
                       ("max_consecutive_rejections", max_consecutive)):
        if not isinstance(value, (int, np.integer)) or value < 1:
            raise ValueError(f"{key} must be a positive integer")

    stats = _make_stats(method)
    stats.update(adaptive=True, tolerance=tol, attempted_steps=0,
                 h_history=[], error_history=[], attempted_h_history=[],
                 attempted_error_history=[], last_rejection_reason=None)
    times, states = [t0], [y0]
    _note_negativity(t0, y0, stats, opts)
    stats["failure"] = _state_failure(y0, opts)
    if stats["failure"] is not None:
        stats["failure_time"] = t0
    h = min(h_max, max(h_min, h0))
    p = 4 if method == "RK4" else 1
    consecutive_rejections = 0

    while times[-1] < tf and stats["failure"] is None:
        time, state = times[-1], states[-1]
        if stats["accepted_steps"] >= opts["max_steps"]:
            stats["failure"], stats["failure_time"] = "max_steps", time
            break
        remaining = tf - time
        h_trial = min(h, remaining)
        t_next = tf if h >= remaining else time + h_trial
        h_trial = t_next - time
        if h_trial <= 0 or time + h_trial / 2 == time:
            stats["failure"], stats["failure_time"] = "time_stagnation", time
            break
        stats["attempted_steps"] += 1
        stats["attempted_h_history"].append(float(h_trial))

        coarse, trial_failure = _step(method, time, state, h_trial, opts, stats)
        fine = None
        if trial_failure is None:
            half, trial_failure = _step(method, time, state, h_trial / 2, opts, stats)
        if trial_failure is None:
            fine, trial_failure = _step(method, time + h_trial / 2, half, h_trial / 2, opts, stats)
        if trial_failure is None:
            with np.errstate(over="ignore", invalid="ignore"):
                error = float(np.linalg.norm(fine - coarse, ord=np.inf) / (2**p - 1))
            if not np.isfinite(error):
                trial_failure = "nonfinite_error_estimate"
                error = np.inf
        else:
            error = np.inf
        stats["attempted_error_history"].append(error)

        if trial_failure is None and error <= tol:
            times.append(float(t_next))
            states.append(fine)
            stats["steps"] += 1
            stats["accepted_steps"] += 1
            stats["h_history"].append(float(h_trial))
            stats["error_history"].append(error)
            _note_negativity(t_next, fine, stats, opts)
            consecutive_rejections = 0
        else:
            stats["rejected_steps"] += 1
            consecutive_rejections += 1
            stats["last_rejection_reason"] = trial_failure or "local_error_exceeds_tolerance"
            if stats["rejected_steps"] >= max_rejected:
                stats["failure"], stats["failure_time"] = "max_rejected_steps", float(t_next)
                break
            if consecutive_rejections >= max_consecutive:
                stats["failure"], stats["failure_time"] = "max_consecutive_rejections", float(t_next)
                break
            if h_trial <= h_min:
                stats["failure"] = "h_min_reached: " + stats["last_rejection_reason"]
                stats["failure_time"] = float(t_next)
                break

        if error == 0:
            factor = max_factor
        elif not np.isfinite(error):
            factor = min_factor
        else:
            # Taking separate powers avoids overflow in tol/error for a tiny error.
            factor = safety * (tol ** (1 / (p + 1))) / (error ** (1 / (p + 1)))
            factor = min(max_factor, max(min_factor, factor))
        h = min(h_max, max(h_min, h_trial * factor))

    stats["converged"] = bool(stats["failure"] is None and times[-1] == tf)
    stats["runtime_seconds"] = perf_counter() - started
    return np.asarray(times), np.asarray(states), stats


def adaptive_rk4(t0, tf, y0, h0, tol, options=None):
    """Convenience wrapper for the assignment's primary adaptive method."""
    return solve_adaptive("RK4", t0, tf, y0, h0, tol, options)


def adaptive_implicit_euler(t0, tf, y0, h0, tol, options=None):
    """Step-doubling IE extension of the teacher's scaffold."""
    return solve_adaptive("IE", t0, tf, y0, h0, tol, options)
