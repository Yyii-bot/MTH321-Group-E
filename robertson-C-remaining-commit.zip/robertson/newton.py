"""Newton iteration with an explicit residual stopping rule and honest costs."""

import numpy as np


def newton_solver(residual, jacobian, z0, tol=1.0e-12, maxiter=30, damping=1.0):
    """Solve F(z)=0, returning ``(z, info)`` without accepting failed solves.

    Stop only when ``||F(z)||_inf <= tol``. ``maxiter`` limits completed
    Newton corrections; even the last correction is followed by a residual
    check. The linear system is solved directly, never by matrix inversion.
    ``damping=1`` gives the assignment's full Newton iteration. A smaller
    constant damping factor is available for experimentation.

    ``info`` counts actual residual/Jacobian calls and attempted linear
    solves; ``iterations`` counts completed updates. A nonconverged iterate
    is returned for diagnosis only and must never be accepted by a solver.
    """
    if not np.isfinite(tol) or tol <= 0:
        raise ValueError("Newton tol must be positive and finite")
    if not isinstance(maxiter, (int, np.integer)) or maxiter < 0:
        raise ValueError("Newton maxiter must be a nonnegative integer")
    if not np.isfinite(damping) or not 0 < damping <= 1:
        raise ValueError("Newton damping must satisfy 0 < damping <= 1")
    z = np.asarray(z0, dtype=float).copy()
    if z.ndim != 1 or z.size == 0:
        raise ValueError("Newton z0 must be a nonempty one-dimensional vector")
    info = dict(converged=False, failure=None, iterations=0, residual=np.inf,
                residual_evals=0, jac_evals=0, linear_solves=0)
    if not np.all(np.isfinite(z)):
        info["failure"] = "nonfinite_newton_initial_guess"
        return z, info

    for iteration in range(maxiter + 1):
        info["residual_evals"] += 1
        with np.errstate(over="ignore", invalid="ignore"):
            value = np.asarray(residual(z), dtype=float)
        if value.shape != z.shape:
            raise ValueError("Newton residual must have the shape of z0")
        if not np.all(np.isfinite(value)):
            info["residual"] = np.inf
            info["failure"] = "nonfinite_newton_residual"
            return z, info
        info["residual"] = float(np.linalg.norm(value, ord=np.inf))
        if info["residual"] <= tol:
            info["converged"] = True
            return z, info
        if iteration == maxiter:
            info["failure"] = "newton_maxiter"
            return z, info
        info["jac_evals"] += 1
        with np.errstate(over="ignore", invalid="ignore"):
            matrix = np.asarray(jacobian(z), dtype=float)
        if matrix.shape != (z.size, z.size):
            raise ValueError("Newton Jacobian must have shape (len(z0), len(z0))")
        if not np.all(np.isfinite(matrix)):
            info["failure"] = "nonfinite_newton_jacobian"
            return z, info
        info["linear_solves"] += 1
        try:
            delta = np.linalg.solve(matrix, -value)
        except np.linalg.LinAlgError:
            info["failure"] = "singular_newton_jacobian"
            return z, info
        with np.errstate(over="ignore", invalid="ignore"):
            z = z + damping * delta
        info["iterations"] += 1
        if not np.all(np.isfinite(z)):
            info["residual"] = np.inf
            info["failure"] = "nonfinite_newton_iterate"
            return z, info

    raise AssertionError("unreachable Newton iteration exit")
