"""Fixed-step Explicit Euler, classical RK4 and Implicit Euler + Newton.

All solvers return ``(t, Y, stats)`` with ``Y.shape == (len(t), 3)``. Finite
negative concentrations are retained so that positivity and accuracy can
be diagnosed independently. Nonfinite/blow-up/Newton failures stop the
integration and return the valid prefix, with the attempted failure time.
"""

from time import perf_counter

import numpy as np

from .model import robertson_rhs, robertson_jacobian
from .newton import newton_solver


DEFAULT_OPTIONS = {
    "newton_tol": 1.0e-12,
    "newton_maxiter": 30,
    "newton_damping": 1.0,
    "blowup_threshold": 1.0e6,
    "negativity_tol": 1.0e-14,
    "max_steps": 5_000_000,
}


def _validate_inputs(t0, tf, y0, h, options):
    """Shared input checks; configuration mistakes are raised immediately."""
    t0, tf, h = float(t0), float(tf), float(h)
    y0 = np.asarray(y0, dtype=float)
    if not np.all(np.isfinite([t0, tf, h])) or tf < t0 or h <= 0:
        raise ValueError("Require finite t0 <= tf and positive finite h")
    if y0.shape != (3,) or not np.all(np.isfinite(y0)):
        raise ValueError("y0 must contain three finite concentrations")
    opts = dict(DEFAULT_OPTIONS)
    if options is not None:
        opts.update(options)
    for key in ("newton_tol", "blowup_threshold"):
        if not np.isfinite(opts[key]) or opts[key] <= 0:
            raise ValueError(f"{key} must be positive and finite")
    if not np.isfinite(opts["negativity_tol"]) or opts["negativity_tol"] < 0:
        raise ValueError("negativity_tol must be finite and nonnegative")
    for key, minimum in (("max_steps", 1), ("newton_maxiter", 0)):
        if not isinstance(opts[key], (int, np.integer)) or opts[key] < minimum:
            raise ValueError(f"{key} must be an integer >= {minimum}")
    if not np.isfinite(opts["newton_damping"]) or not 0 < opts["newton_damping"] <= 1:
        raise ValueError("newton_damping must satisfy 0 < damping <= 1")
    return t0, tf, y0.copy(), h, opts


def _make_stats(method):
    return dict(
        method=method, steps=0, rhs_evals=0, jac_evals=0, linear_solves=0,
        newton_iters=0, newton_iters_per_step=[], newton_residuals=[],
        accepted_steps=0, rejected_steps=0, converged=False, failure=None,
        failure_time=None, first_negative_time=None, runtime_seconds=0.0,
    )


def _state_failure(y, options):
    if not np.all(np.isfinite(y)):
        return "nonfinite_state"
    if np.max(np.abs(y)) > options["blowup_threshold"]:
        return "blowup_threshold"
    return None


def _note_negativity(t, y, stats, options):
    if stats["first_negative_time"] is None and np.any(y < -options["negativity_tol"]):
        stats["first_negative_time"] = float(t)


def _step(method, t, y, h, options, stats):
    """Attempt one base-method step, updating true call counters in-place.

    Adaptive calls use this same kernel, including for rejected trials.
    Newton histories contain one record per nonlinear solve attempted
    (three solves per complete IE step-doubling trial), not only accepted
    adaptive macro steps. Residual evaluations each call the model once.
    """
    def f(time, state):
        stats["rhs_evals"] += 1
        return robertson_rhs(time, state)

    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        if method == "EE":
            candidate = y + h * f(t, y)
        elif method == "RK4":
            k1 = f(t, y)
            k2 = f(t + h / 2, y + h * k1 / 2)
            k3 = f(t + h / 2, y + h * k2 / 2)
            k4 = f(t + h, y + h * k3)
            candidate = y + h * (k1 + 2 * k2 + 2 * k3 + k4) / 6
        elif method == "IE":
            def residual(z):
                return z - y - h * f(t + h, z)

            def jacobian(z):
                stats["jac_evals"] += 1
                return np.eye(3) - h * robertson_jacobian(t + h, z)

            candidate, info = newton_solver(
                residual, jacobian, y, tol=options["newton_tol"],
                maxiter=options["newton_maxiter"], damping=options["newton_damping"],
            )
            stats["newton_iters"] += info["iterations"]
            stats["linear_solves"] += info["linear_solves"]
            stats["newton_iters_per_step"].append(info["iterations"])
            stats["newton_residuals"].append(info["residual"])
            if not info["converged"]:
                return candidate, info["failure"]
        else:
            raise ValueError("method must be EE, RK4 or IE")
    return candidate, _state_failure(candidate, options)


def solve_fixed(method, t0, tf, y0, h, options=None):
    """Integrate on a fixed nominal grid; shorten the last step to hit tf.

    ``steps``/``accepted_steps`` count stored, successfully completed time
    steps. ``rejected_steps`` is zero for fixed stepping; an unsuccessful
    attempt ends the run and still contributes to all work counters.
    ``converged`` means reached tf without a solver failure, not a claim
    of accuracy, positivity or nonlinear dynamical stability.
    """
    started = perf_counter()
    method = str(method).upper()
    if method not in ("EE", "RK4", "IE"):
        raise ValueError("method must be EE, RK4 or IE")
    t0, tf, y0, h, opts = _validate_inputs(t0, tf, y0, h, options)
    stats = _make_stats(method)
    ratio = (tf - t0) / h
    capacity = min(opts["max_steps"], int(np.ceil(ratio))) if np.isfinite(ratio) else opts["max_steps"]
    times = np.empty(capacity + 1)
    states = np.empty((capacity + 1, 3))
    times[0], states[0] = t0, y0
    _note_negativity(t0, y0, stats, opts)
    stats["failure"] = _state_failure(y0, opts)
    if stats["failure"]:
        stats["failure_time"] = t0
    index = 0
    while times[index] < tf and stats["failure"] is None:
        if index >= capacity:
            stats["failure"], stats["failure_time"] = "max_steps", float(times[index])
            break
        # Computing grid points from the index prevents accumulated time drift.
        t_next = min(tf, t0 + (index + 1) * h)
        h_actual = t_next - times[index]
        if h_actual <= 0:
            stats["failure"], stats["failure_time"] = "time_stagnation", float(times[index])
            break
        candidate, failure = _step(method, times[index], states[index], h_actual, opts, stats)
        if failure is not None:
            stats["failure"], stats["failure_time"] = failure, float(t_next)
            break
        index += 1
        times[index], states[index] = t_next, candidate
        _note_negativity(t_next, candidate, stats, opts)
    stats["steps"] = stats["accepted_steps"] = index
    stats["converged"] = bool(stats["failure"] is None and times[index] == tf)
    stats["runtime_seconds"] = perf_counter() - started
    return times[:index + 1].copy(), states[:index + 1].copy(), stats


def explicit_euler(t0, tf, y0, h, options=None):
    """Fixed-step EE wrapper with the shared solver interface."""
    return solve_fixed("EE", t0, tf, y0, h, options)


def rk4(t0, tf, y0, h, options=None):
    """Fixed-step classical four-stage RK4 wrapper."""
    return solve_fixed("RK4", t0, tf, y0, h, options)


def implicit_euler(t0, tf, y0, h, options=None):
    """Fixed-step IE wrapper, solving each step with analytic-Jacobian Newton."""
    return solve_fixed("IE", t0, tf, y0, h, options)
