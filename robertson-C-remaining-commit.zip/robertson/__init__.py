"""Topic 3 Robertson: student numerical methods and reproducible experiments."""

__version__ = "1.0.0"
