"""Run the task-sheet experiments and export every number from actual runs.

No textbook check values are used in any computation. Default outputs are
development evidence until the team supplies its verified reference dataset.
"""

import argparse
import csv
import hashlib
import json
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import scipy
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from .config import default_config
from .solvers import solve_fixed
from .adaptive import solve_adaptive
from .reference import create_development_reference, load_reference, save_reference
from .diagnostics import error_diagnostics, align_to_reference
from .stability import eigenanalysis, R_euler, R_rk4, R_implicit_euler


def clean(value):
    """Standards-compliant JSON: non-finite or missing results become null."""
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [clean(v) for v in value]
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if isinstance(value, (np.integer, int)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, Path):
        return str(value)
    return value


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(clean(value), indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")


def write_csv(path, rows):
    if not rows:
        return
    columns = list(dict.fromkeys(k for row in rows for k in row))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: clean(v) for k, v in row.items()})


def deep_update(base, updates):
    for key, value in updates.items():
        if key not in base:
            raise ValueError(f"Unknown config key: {key}")
        if isinstance(base[key], dict) and isinstance(value, dict):
            deep_update(base[key], value)
        else:
            base[key] = value


def reference_kind(reference):
    """A development provenance label survives explicit --reference loading."""
    meta_text = (str(reference.metadata.get("source", "")) + " "
                 + str(reference.metadata.get("status", ""))).lower()
    return "development" if "development" in meta_text else "team"


class ExperimentRunner:
    def __init__(self, root, config, reference, kind, save_trajectories=False):
        self.root, self.cfg, self.ref, self.kind = root, config, reference, kind
        self.results = root / "results" / kind
        self.figures = root / "figures" / kind
        for path in (self.results, self.figures, self.results / "runs"):
            path.mkdir(parents=True, exist_ok=True)
        self.save_trajectories = save_trajectories
        self.rows = []
        self.trace = {}
        self.seq = 0
        self.label = "DEVELOPMENT ONLY" if kind == "development" else "TEAM-SUPPLIED REFERENCE"
        plt.rcParams.update({"font.size": 10, "axes.spines.top": False,
                             "axes.spines.right": False, "savefig.dpi": config["plot_dpi"]})

    def savefig(self, fig, name):
        fig.text(0.99, 0.008, self.label, ha="right", color="#8f4a15", fontsize=8)
        fig.tight_layout(rect=(0, 0.035, 1, 1))
        fig.savefig(self.figures / f"{name}.png")
        fig.savefig(self.figures / f"{name}.pdf")
        plt.close(fig)

    def run(self, method, h, experiment, *, newton_tol=None, adaptive_tol=None, keep_trace=False):
        self.seq += 1
        run_id = f"{self.seq:03d}_{experiment}_{method}"
        options = dict(self.cfg["solver_options"])
        if newton_tol is not None:
            options["newton_tol"] = newton_tol
        print(f"  {run_id}: h={h:g}" + (f", tol={adaptive_tol:g}" if adaptive_tol else ""), flush=True)
        args = (method, self.cfg["t0"], self.cfg["tf"], self.cfg["y0"], h)
        if adaptive_tol is None:
            t, Y, stats = solve_fixed(*args, options=options)
        else:
            t, Y, stats = solve_adaptive(*args, tol=adaptive_tol, options=options)
        completed = bool(stats["converged"] and np.isclose(t[-1], self.cfg["tf"], rtol=0, atol=1e-11))
        diag = error_diagnostics(t, Y, self.ref,
                                 accuracy_threshold=self.cfg["accuracy_threshold"],
                                 negativity_tol=options["negativity_tol"], completed=completed)
        ref_tv = float(np.abs(np.diff(self.ref.Y[:, 1])).sum())
        tv = float(np.abs(np.diff(Y[:, 1])).sum())
        tv_ratio = tv / max(ref_tv, np.finfo(float).tiny)
        max_state = float(np.max(np.abs(Y)))
        stable = bool(completed and not stats["failure"]
                      and max_state <= self.cfg["stable_max_abs_state"]
                      and tv_ratio <= self.cfg["stable_y2_tv_ratio"])
        row = {"run_id": run_id, "experiment": experiment,
               "method": ("adaptive_" if adaptive_tol is not None else "") + method,
               "h": h, "newton_tol": options["newton_tol"] if method == "IE" else None,
               "adaptive_tol": adaptive_tol, "reference_kind": self.kind,
               "completed": completed, "stable": stable,
               "y2_tv_ratio": tv_ratio, "max_abs_state": max_state,
               **{k: stats.get(k) for k in ("steps", "rhs_evals", "jac_evals", "linear_solves",
                                            "newton_iters", "accepted_steps", "rejected_steps",
                                            "converged", "failure", "failure_time", "runtime_seconds")},
               **diag, "y2_40": float(Y[-1, 1]) if completed and np.isclose(t[-1],40.0,rtol=0,atol=1e-12) else None}
        row["stable"] = stable
        self.rows.append(row)
        # Long per-step histories belong in compressed numeric arrays, not
        # multi-megabyte JSON lists that are awkward to upload and review.
        histories = {k: np.asarray(v) for k, v in stats.items()
                     if isinstance(v, (list, np.ndarray)) and len(v)}
        history_file = f"{run_id}_history.npz" if histories else None
        if histories:
            np.savez_compressed(self.results / "runs" / history_file, **histories)
        scalar_stats = {k: v for k,v in stats.items() if not isinstance(v,(list,np.ndarray))}
        write_json(self.results / "runs" / f"{run_id}.json", {"parameters": {"h": h, "adaptive_tol": adaptive_tol,
                   "options": options}, "summary": row, "stats": scalar_stats,
                   "history_file": history_file, "history_lengths": {k:len(v) for k,v in histories.items()}})
        # Common output grid; costs of diagnostic interpolation are not solver work.
        mask = (self.ref.t >= t[0]) & (self.ref.t <= t[-1])
        times = self.ref.t[mask]
        if len(t) > 1:
            sampled, _ = align_to_reference(t, Y, times)
            np.savez_compressed(self.results / "runs" / f"{run_id}_samples.npz",
                                t=times, Y=sampled, reference_Y=self.ref.Y[mask],
                                completed=completed, final_native_t=t[-1], final_native_Y=Y[-1])
        if self.save_trajectories:
            path = self.results / "trajectories"
            path.mkdir(exist_ok=True)
            np.savez_compressed(path / f"{run_id}.npz", t=t, Y=Y)
        if keep_trace:
            # Retain plotting-sized arrays; diagnostics above used every native node.
            idx = np.unique(np.r_[np.arange(min(1500, len(t))), np.linspace(0, len(t)-1, min(6000, len(t)), dtype=int)])
            self.trace[run_id] = (t[idx], Y[idx], stats)
        write_csv(self.results / "all_runs.csv", self.rows)
        return row

    def reference_plot(self):
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        t, Y = self.ref.t[1:], self.ref.Y[1:]
        axes[0].semilogx(t, Y[:, 0], label="y1")
        axes[0].semilogx(t, Y[:, 2], label="y3")
        axes[1].semilogx(t, Y[:, 1], label="y2", color="#a64b25")
        for ax in axes:
            ax.set(xlabel="Time t", ylabel="Concentration (model units)")
            ax.grid(alpha=.25); ax.legend()
        fig.suptitle("Reference species trajectories")
        self.savefig(fig, "01_reference_species")

    def convergence(self):
        rows = []
        for method, hs in self.cfg["convergence_h"].items():
            previous = None
            for h in hs:
                row = dict(self.run(method, h, "convergence"))
                error = row["E_full"]
                row["observed_order"] = None
                if previous and error is not None and np.isfinite(error) and error > 0:
                    ep, hp = previous
                    if ep is not None and np.isfinite(ep) and ep > 0:
                        row["observed_order"] = float(np.log(ep/error) / np.log(hp/h))
                previous = (error, h)
                rows.append(row)
        write_csv(self.results / "convergence.csv", rows)
        fig, ax = plt.subplots(figsize=(7, 4.5))
        for method in self.cfg["convergence_h"]:
            group = [r for r in rows if r["method"] == method and r["completed"]]
            ax.loglog([r["h"] for r in group], [r["E_full"] for r in group], "o-", label=method)
        ax.set(xlabel="Nominal step h", ylabel="Sampled full-state error (2-norm)", title="Fixed-step convergence")
        ax.grid(which="both", alpha=.2); ax.legend()
        self.savefig(fig, "02_convergence")
        return rows

    def stability(self):
        eigen = eigenanalysis(self.ref, zero_threshold=self.cfg["zero_threshold"])
        np.savez_compressed(self.results / "eigenanalysis.npz", **eigen)
        keys = ("t", "lambda_slow", "lambda_fast", "stiffness_ratio", "zero_eigenvalue", "zero_count", "valid", "ee_h_limit")
        write_csv(self.results / "eigenanalysis.csv", [{k: float(np.real(eigen[k][i])) if k not in ("valid", "zero_count")
                 else eigen[k][i] for k in keys} for i in range(len(eigen["t"]))])
        t = eigen["t"]
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        for name in ("slow", "fast"):
            axes[0].loglog(t, np.abs(np.real(eigen[f"lambda_{name}"])), label=name)
        axes[0].set(xlabel="Time t", ylabel="|Re(lambda)|", title="Two nonzero modes")
        axes[0].legend()
        axes[1].loglog(t, eigen["stiffness_ratio"])
        axes[1].set(xlabel="Time t", ylabel="Stiffness ratio S(t)", title="Zero mode excluded")
        for ax in axes: ax.grid(which="both", alpha=.2)
        self.savefig(fig, "03_eigenvalues_and_stiffness")
        x, y = np.linspace(-4, 3, 700), np.linspace(-4, 4, 700)
        X, Y = np.meshgrid(x, y); Z = X + 1j * Y
        functions = (("EE", R_euler), ("RK4", R_rk4), ("IE", R_implicit_euler))
        for method, fn in functions:
            with np.errstate(divide="ignore", invalid="ignore"):
                values = np.abs(fn(Z))
            fig, ax = plt.subplots(figsize=(5.5, 4.5))
            ax.contourf(X, Y, (values <= 1).astype(float), levels=[.5, 1.5], colors=["#c4e6ea"])
            ax.contour(X, Y, values, levels=[1], colors=["#15717b"])
            ax.axhline(0, color="gray", lw=.5); ax.axvline(0, color="gray", lw=.5)
            ax.set(xlabel="Re(z)", ylabel="Im(z)", title=f"{method}: absolute stability region")
            ax.set_aspect("equal"); self.savefig(fig, f"04_stability_{method}")
        fig, ax = plt.subplots(figsize=(7, 4.5))
        ax.contour(X, Y, np.abs(R_euler(Z)), levels=[1], colors=["#15717b"])
        for h in (4e-4, 8e-4):
            lam = np.concatenate((eigen["lambda_slow"], eigen["lambda_fast"]))
            ax.scatter(h*lam.real, h*lam.imag, s=7, alpha=.5, label=f"h={h:g}")
        ax.set(xlabel="Re(h lambda)", ylabel="Im(h lambda)", title="EE: local frozen-Jacobian diagnostic")
        ax.legend(); ax.grid(alpha=.2); self.savefig(fig, "05_ee_eigenvalue_overlay")
        return eigen

    def failure_sweep(self):
        rows = [self.run("EE", h, "failure", keep_trace=True) for h in self.cfg["ee_failure_h"]]
        # Resolve a transition empirically, rather than declaring 5.9e-4 exact.
        ordered = sorted(rows, key=lambda r: r["h"])
        for left, right in zip(ordered[:-1], ordered[1:]):
            if left["stable"] != right["stable"]:
                rows.append(self.run("EE", .5*(left["h"]+right["h"]), "failure_refinement", keep_trace=True))
        write_csv(self.results / "ee_failure.csv", rows)
        fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
        for row in rows:
            t, Y, _ = self.trace[row["run_id"]]
            label = f"h={row['h']:g}, stable={row['stable']}"
            axes[0].plot(t, Y[:, 1], label=label, lw=.8)
            axes[1].plot(t, Y[:, 0], label=f"h={row['h']:g}", lw=.8)
        axes[0].plot(self.ref.t, self.ref.Y[:,1], "k--", label="reference")
        axes[1].plot(self.ref.t, self.ref.Y[:,0], "k--", label="reference")
        axes[0].set(xlabel="Time t", ylabel="y2", title="EE near the stability boundary")
        axes[0].set_yscale("symlog", linthresh=1e-5)
        axes[1].set(xlabel="Time t", ylabel="y1", title="Slow species and failure")
        axes[1].set_yscale("symlog", linthresh=1)
        for ax in axes: ax.grid(alpha=.2); ax.legend(fontsize=7)
        self.savefig(fig, "06_ee_failure")
        return rows

    def newton_sweep(self):
        rows = [self.run("IE", self.cfg["newton_sweep_h"], "newton_tolerance", newton_tol=tol)
                for tol in self.cfg["newton_tolerances"]]
        write_csv(self.results / "newton_tolerance.csv", rows)
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        axes[0].loglog([r["newton_tol"] for r in rows], [r["E_full"] for r in rows], "o-")
        axes[0].set(xlabel="Newton residual tolerance", ylabel="Sampled full-state error", title="Fixed h: error plateau")
        axes[1].semilogx([r["newton_tol"] for r in rows], [r["newton_iters"] for r in rows], "o-")
        axes[1].set(xlabel="Newton residual tolerance", ylabel="Total Newton updates", title="Algebraic solve work")
        for ax in axes: ax.grid(alpha=.2)
        self.savefig(fig, "07_newton_tolerance")
        return rows

    def adaptive(self):
        rows = []
        for method in ("RK4", "IE"):
            for tol in self.cfg["adaptive_tolerances"]:
                rows.append(self.run(method, self.cfg["adaptive_h0"], "adaptive", adaptive_tol=tol, keep_trace=True))
        write_csv(self.results / "adaptive.csv", rows)
        fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
        for method, ax in zip(("RK4", "IE"), axes):
            for row in rows:
                if row["method"] != f"adaptive_{method}": continue
                _, _, stats = self.trace[row["run_id"]]
                h = np.asarray(stats["h_history"])
                ax.loglog(np.maximum(np.cumsum(h)-h, 1e-8), h, label=f"tol={row['adaptive_tol']:g}", lw=.8)
            ax.set(xlabel="Step start time (0 shown at 1e-8)", ylabel="Accepted macro step h", title=f"Adaptive {method}")
            ax.grid(which="both", alpha=.2); ax.legend()
        self.savefig(fig, "08_adaptive_steps")
        fig, ax = plt.subplots(figsize=(7, 4.5))
        for method in ("adaptive_RK4", "adaptive_IE"):
            group = [r for r in rows if r["method"] == method]
            ax.loglog([r["adaptive_tol"] for r in group], [r["E_full"] for r in group], "o-", label=method)
        ax.set(xlabel="Local absolute error tolerance", ylabel="Measured sampled global error", title="Local tolerance versus actual error")
        ax.legend(); ax.grid(which="both", alpha=.2); self.savefig(fig, "09_adaptive_accuracy")
        return rows

    def matched_and_cost(self, convergence):
        usable = [r for r in convergence if r["completed"] and r["stable"]
                  and r["nonnegative_flag"] and np.isfinite(r["E_full"]) and r["E_full"] > 0]
        ee = [r for r in usable if r["method"] == "EE"]
        ie = [r for r in usable if r["method"] == "IE"]
        if not ee or not ie:
            raise RuntimeError("Matched-error requires completed EE and IE runs")
        target = ee[0]
        best = min(ie, key=lambda r: abs(np.log(r["E_full"]/target["E_full"])))
        ratio = lambda r: max(r["E_full"],target["E_full"])/min(r["E_full"],target["E_full"])
        for _ in range(self.cfg["matched_max_refinements"]):
            if ratio(best) <= self.cfg["matched_error_ratio"]: break
            # First-order IE gives a starting proposal; measured error still decides.
            h = best["h"] * np.clip(target["E_full"]/best["E_full"], .25, 4.)
            trial = self.run("IE", float(h), "matched_refinement")
            if not (trial["completed"] and trial["stable"] and trial["nonnegative_flag"]
                    and np.isfinite(trial["E_full"]) and trial["E_full"] > 0): break
            best = trial
        matched = [{**r, "target_E_full": target["E_full"], "pair_error_ratio": ratio(best),
                    "matched_within_ratio": ratio(best) <= self.cfg["matched_error_ratio"]} for r in (target,best)]
        write_csv(self.results / "matched_error.csv", matched)
        pool = [r for r in self.rows if r["completed"] and r["stable"] and r.get("nonnegative_flag", False)
                and r["experiment"] != "newton_tolerance" and np.isfinite(r["E_full"])]
        costs = []
        for error_target in sorted(set(float(r["E_full"])*1.001 for r in ee), reverse=True):
            for method in ("EE", "RK4", "IE", "adaptive_RK4", "adaptive_IE"):
                candidates = [r for r in pool if r["method"] == method and r["E_full"] <= error_target]
                if candidates:
                    chosen = min(candidates, key=lambda r: r["rhs_evals"])
                    costs.append({"accuracy_target": error_target, "target_met": True, **chosen})
                else:
                    costs.append({"accuracy_target": error_target, "target_met": False, "method": method,
                                  "note": "No tested stable nonnegative run met this target"})
        write_csv(self.results / "cost_vs_accuracy.csv", costs)
        fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
        for method in ("EE", "RK4", "IE", "adaptive_RK4", "adaptive_IE"):
            group = sorted([r for r in pool if r["method"] == method], key=lambda r:r["E_full"])
            if not group: continue
            axes[0].loglog([r["rhs_evals"] for r in group], [r["E_full"] for r in group], "o-", label=method)
            axes[1].loglog([r["runtime_seconds"] for r in group], [r["E_full"] for r in group], "o-", label=method)
        axes[0].set(xlabel="Actual integration RHS calls", ylabel="Sampled full-state error", title="Error versus counted work")
        axes[1].set(xlabel="Integration wall time (seconds)", ylabel="Sampled full-state error", title="Machine-dependent timing")
        for ax in axes: ax.legend(fontsize=8); ax.grid(which="both", alpha=.2)
        self.savefig(fig, "10_cost_vs_accuracy")
        return matched

    def diagnostics_plot(self):
        keys = ("run_id", "method", "h", "adaptive_tol", "newton_tol", "completed", "stable",
                "E_full", "E_40", "E_cons", "y_min", "first_negative_time", "nonnegative_flag", "accurate_flag")
        write_csv(self.results / "diagnostics.csv", [{k:r.get(k) for k in keys} for r in self.rows])
        group = [r for r in self.rows if r["experiment"] == "convergence"]
        fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
        for method in ("EE", "RK4", "IE"):
            rows = [r for r in group if r["method"] == method]
            axes[0].loglog([r["h"] for r in rows], [max(r["E_cons"],1e-18) for r in rows], "o-", label=method)
            axes[1].semilogx([r["h"] for r in rows], [r["y_min"] for r in rows], "o-", label=method)
        axes[0].set(xlabel="Nominal step h", ylabel="Max |sum(y)-1|", title="Conservation on native nodes")
        axes[1].set(xlabel="Nominal step h", ylabel="Min concentration, including t=0", title="Non-negativity on native nodes")
        for ax in axes: ax.legend(); ax.grid(alpha=.2)
        self.savefig(fig, "11_diagnostics")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, help="Team NPZ with t_ref, y_ref; omitted = DEVELOPMENT ONLY")
    parser.add_argument("--config", type=Path, help="JSON overrides of robertson/config.py")
    parser.add_argument("--save-trajectories", action="store_true", help="Also save full native trajectories (large)")
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    cfg = default_config()
    if args.config:
        deep_update(cfg, json.loads(args.config.read_text(encoding="utf-8")))
    started = time.perf_counter()
    if args.reference:
        ref = load_reference(args.reference)
        # Supplying the development NPZ explicitly must not promote its provenance.
        kind = reference_kind(ref)
        reference_file = args.reference.resolve()
    else:
        print("DEVELOPMENT ONLY: generating cross-checked temporary reference", flush=True)
        ref = create_development_reference(t_end=cfg["tf"], n_points=cfg["reference_points"],
                                           rtol=cfg["reference_rtol"], atol=cfg["reference_atol"])
        kind = "development"
        reference_file = root / "data" / "development_reference.npz"
        reference_file.parent.mkdir(exist_ok=True)
        save_reference(ref, reference_file)
    runner = ExperimentRunner(root,cfg,ref,kind,args.save_trajectories)
    write_json(runner.results / "config_used.json", cfg)
    manifest = {"status": "running", "reference_kind": kind,
                "reference_file": reference_file.name, "reference_sha256": hashlib.sha256(reference_file.read_bytes()).hexdigest(),
                "reference_metadata": ref.metadata, "config_sha256": hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest(),
                "generated_utc": datetime.now(timezone.utc).isoformat(),
                "environment": {"python": platform.python_version(), "platform": platform.platform(),
                                "numpy": np.__version__, "scipy": scipy.__version__, "matplotlib": matplotlib.__version__},
                "cost_policy": "Solver RHS/Jacobian/linear solve calls include rejected attempts; excludes reference, interpolation, plotting and file IO.",
                "error_policy": "E_full is max 2-norm on shared reference output grid, not a continuous-in-time bound.",
                "stable_policy": "Completed; no solver failure; max_abs_state <= configured limit; native y2 total variation / reference y2 TV <= configured limit. Empirical diagnostic only."}
    write_json(runner.results / "manifest.json", manifest)
    try:
        runner.reference_plot()
        print("[1/7] Fixed-step convergence", flush=True); conv = runner.convergence()
        print("[2/7] Stability and eigenanalysis", flush=True); eigen = runner.stability()
        print("[3/7] EE failure sweep", flush=True); runner.failure_sweep()
        print("[4/7] Newton tolerance sweep", flush=True); runner.newton_sweep()
        print("[5/7] Adaptive step doubling", flush=True); runner.adaptive()
        print("[6/7] Matched error and cost", flush=True); matched = runner.matched_and_cost(conv)
        print("[7/7] Diagnostics and manifest", flush=True); runner.diagnostics_plot()
        manifest.update(status="complete", total_runs=len(runner.rows),
                        completed_runs=sum(bool(r["completed"]) for r in runner.rows),
                        failed_runs=sum(not r["completed"] for r in runner.rows),
                        elapsed_seconds=time.perf_counter()-started,
                        matched_within_ratio=matched[0]["matched_within_ratio"],
                        invalid_eigenvalue_samples=int(np.count_nonzero(~eigen["valid"])))
        write_json(runner.results / "manifest.json", manifest)
        summary = ["# 本次运行摘要", "", f"参考解标记：**{runner.label}**。", "",
                   "下面是程序实测摘要；development 结果不代表团队最终确认的结果。", "",
                   f"- 执行 {len(runner.rows)} 个算例：{manifest['completed_runs']} 个到达终点，{manifest['failed_runs']} 个数值失败并保留记录。",
                   f"- 总耗时 {manifest['elapsed_seconds']:.1f} 秒（含参考构建、图表和文件输出）。",
                   f"- EE/IE matched-error 误差比：{matched[0]['pair_error_ratio']:.4g}；",
                   f"  是否落在配置的 {cfg['matched_error_ratio']:g} 范围内：{matched[0]['matched_within_ratio']}。",
                   "", "## 逐次减半的实测收敛阶", "", "| Method | h | E_full | Observed order |", "|---|---:|---:|---:|"]
        for r in conv:
            p = r["observed_order"]
            summary.append(f"| {r['method']} | {r['h']:.4g} | {r['E_full']:.6g} | {p:.4f} |" if p is not None else
                           f"| {r['method']} | {r['h']:.4g} | {r['E_full']:.6g} | - |")
        summary += ["", "## 阅读结果", "", "完整参数、参考 provenance、库版本见 manifest.json 和 config_used.json。",
                    "所有统计表都含 run_id，可追溯 runs/ 中的参数、计数、Newton记录与共同时间网格上的数值样本。",
                    "失败算例的 E_full/E_40 留空，不把终止前的局部误差冒充全程误差。",
                    "局部 tolerance 不等于全局误差保证；请同时查看 adaptive.csv 的实测误差。"]
        (runner.results / "SUMMARY.md").write_text("\n".join(summary)+"\n",encoding="utf-8")
        print(f"Done. Results: {runner.results}\nFigures: {runner.figures}", flush=True)
        return 0
    except Exception as exc:
        manifest.update(status="failed", error=f"{type(exc).__name__}: {exc}", elapsed_seconds=time.perf_counter()-started)
        write_json(runner.results / "manifest.json", manifest)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
