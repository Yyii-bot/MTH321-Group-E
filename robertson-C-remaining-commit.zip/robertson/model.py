"""Robertson Topic 3 model; the three concentrations sum to one initially.

The rate constants are model inputs from the assignment, not fitted values.
The argument ``t`` is kept for the usual ODE interface, although this model
is autonomous. No clipping or conservation projection is applied.
"""

import numpy as np


def robertson_rhs(t, y):
    """Return f(t, y) for y = [y1, y2, y3], as a one-dimensional array."""
    y1, y2, y3 = y
    forward = 0.04 * y1
    reverse = 1.0e4 * y2 * y3
    reaction = 3.0e7 * y2 * y2
    return np.array([-forward + reverse, forward - reverse - reaction, reaction])


def robertson_jacobian(t, y):
    """Analytic Jacobian J[i,j] = df_i/dy_j; its columns sum to zero."""
    _, y2, y3 = y
    return np.array(
        [
            [-0.04, 1.0e4 * y3, 1.0e4 * y2],
            [0.04, -1.0e4 * y3 - 6.0e7 * y2, -1.0e4 * y2],
            [0.0, 6.0e7 * y2, 0.0],
        ]
    )
