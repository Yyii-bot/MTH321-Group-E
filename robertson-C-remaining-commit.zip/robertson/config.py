"""All experiment choices in one place; values are adjustable, not benchmarks."""

from copy import deepcopy

DEFAULT = {
    "t0": 0.0,
    "tf": 40.0,
    "y0": [1.0, 0.0, 0.0],
    "reference_points": 400,
    "reference_rtol": 1e-11,
    "reference_atol": 1e-14,
    "accuracy_threshold": 1e-5,
    "zero_threshold": 1e-10,
    "stable_max_abs_state": 2.0,
    "stable_y2_tv_ratio": 10.0,
    "solver_options": {
        "newton_tol": 1e-12,
        "newton_maxiter": 30,
        "negativity_tol": 1e-12,
        "blowup_threshold": 1e6,
        "max_steps": 2000000,
        "h_min": 1e-12,
        "h_max": 0.1,
        "safety": 0.9,
    },
    "convergence_h": {
        "EE": [4e-4, 2e-4, 1e-4, 5e-5],
        "RK4": [5e-4, 2.5e-4, 1.25e-4, 6.25e-5],
        "IE": [2e-3, 1e-3, 5e-4, 2.5e-4],
    },
    "ee_failure_h": [8e-4, 6e-4, 5e-4, 4e-4],
    "newton_sweep_h": 0.1,
    "newton_tolerances": [1e-4, 1e-6, 1e-8, 1e-10, 1e-12],
    "adaptive_h0": 1e-3,
    "adaptive_tolerances": [1e-5, 1e-6, 1e-7, 1e-9, 1e-11],
    "matched_error_ratio": 1.15,
    "matched_max_refinements": 4,
    "plot_dpi": 160,
}


def default_config():
    return deepcopy(DEFAULT)
