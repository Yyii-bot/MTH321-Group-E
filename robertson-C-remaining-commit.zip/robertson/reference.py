"""Load the team's reference, or explicitly generate a development-only oracle.

The assignment says that the team's verified reference already exists.  The
development generator is an integration aid, never a claim that this is that
team reference.  Its provenance travels with every saved data file.
"""

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Callable

import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicHermiteSpline

from .model import robertson_jacobian, robertson_rhs


@dataclass
class Reference:
    """Reference samples in row-per-time format, with no extrapolation."""

    t: np.ndarray
    Y: np.ndarray
    metadata: dict = field(default_factory=dict)
    _evaluator: Callable | None = field(default=None, repr=False)

    def __post_init__(self):
        self.t = np.asarray(self.t, dtype=float)
        self.Y = np.asarray(self.Y, dtype=float)
        if self.t.ndim != 1 or len(self.t) < 2:
            raise ValueError("Reference times must be a 1D array with at least two points.")
        if self.Y.shape != (len(self.t), 3):
            raise ValueError("Reference y_ref must have shape (len(t_ref), 3).")
        if not np.all(np.isfinite(self.t)) or not np.all(np.isfinite(self.Y)):
            raise ValueError("Reference arrays must be finite.")
        if not np.all(np.diff(self.t) > 0):
            raise ValueError("Reference times must be strictly increasing.")
        if self.t[0] < 0:
            raise ValueError("Reference times cannot be negative.")
        if not isinstance(self.metadata, dict):
            raise ValueError("Reference metadata must be a JSON object.")
        if self._evaluator is None:
            slopes = np.array([robertson_rhs(t, y) for t, y in zip(self.t, self.Y)])
            self._evaluator = CubicHermiteSpline(self.t, self.Y, slopes, extrapolate=False)

    def evaluate(self, t):
        """Evaluate only inside the stored time interval; scalar -> shape (3,)."""
        times = np.asarray(t, dtype=float)
        if not np.all(np.isfinite(times)):
            raise ValueError("Evaluation times must be finite.")
        if np.any(times < self.t[0]) or np.any(times > self.t[-1]):
            raise ValueError("Reference extrapolation is not permitted.")
        return np.asarray(self._evaluator(times), dtype=float)


def load_reference(path):
    """Load a team NPZ with t_ref, y_ref, and optional scalar JSON metadata.

    Required coverage is [0, 40], with >=200 positive output times.  A logarithmic
    grid is recommended by the brief; an existing team's valid grid is retained.
    Shape/coverage checks are not independent numerical validation of team data.
    """
    path = Path(path)
    with np.load(path, allow_pickle=False) as data:
        if not {"t_ref", "y_ref"}.issubset(data.files):
            raise ValueError("Reference NPZ must contain t_ref and y_ref.")
        metadata = {}
        if "metadata" in data.files:
            encoded = data["metadata"]
            if encoded.ndim != 0:
                raise ValueError("metadata must be a scalar JSON string.")
            raw = encoded.item()
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8")
            if not isinstance(raw, str):
                raise ValueError("metadata must be a scalar JSON string.")
            metadata = json.loads(raw)
        reference = Reference(data["t_ref"].copy(), data["y_ref"].copy(), metadata)
    if reference.t[0] != 0.0 or not np.isclose(reference.t[-1], 40.0, rtol=0, atol=1e-12):
        raise ValueError("The Topic 3 reference must start at t=0 and end at t=40.")
    if np.count_nonzero(reference.t > 0) < 200:
        raise ValueError("Reference must contain at least 200 positive output times.")
    if not np.allclose(reference.Y[0], [1.0, 0.0, 0.0], rtol=0, atol=1e-12):
        raise ValueError("Reference initial state must be [1, 0, 0].")
    reference.metadata.setdefault("source", "team_supplied")
    reference.metadata.setdefault(
        "validation_note", "Only file/shape/coverage checks performed on supplied reference."
    )
    reference.metadata["loaded_from"] = str(path)
    reference.metadata["loaded_interpolation"] = "RHS-based cubic Hermite; no extrapolation"
    return reference


def save_reference(reference, path):
    """Write portable arrays and JSON provenance; no pickle/object arrays."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path,
        t_ref=reference.t,
        y_ref=reference.Y,
        metadata=json.dumps(reference.metadata, ensure_ascii=False, sort_keys=True),
    )
    return path


def create_development_reference(t_end=40.0, n_points=400, rtol=1e-10, atol=1e-13):
    """Cross-check Radau/BDF and 100x tighter solves for a DEVELOPMENT ONLY oracle.

    The returned samples use tight Radau.  Error comparisons below are sampled
    discrepancies, not certified error bounds.  rtol tightening observes SciPy's
    floating-point lower limit; the effective values are recorded.
    """
    if not np.isfinite(t_end) or t_end <= 1e-8:
        raise ValueError("t_end must exceed 1e-8.")
    if int(n_points) != n_points or n_points < 200:
        raise ValueError("n_points must be an integer >=200.")
    if not np.isfinite(rtol) or not np.isfinite(atol) or rtol <= 0 or atol <= 0:
        raise ValueError("Reference tolerances must be finite and positive.")
    scipy_rtol_floor = 100 * np.finfo(float).eps
    loose_rtol = max(float(rtol), scipy_rtol_floor)
    tight_rtol = max(float(rtol) / 100, scipy_rtol_floor)
    tight_atol = float(atol) / 100
    t = np.concatenate(([0.0], np.geomspace(1e-8, float(t_end), int(n_points))))
    solutions = {}
    solve_stats = {}
    for method in ("Radau", "BDF"):
        for level, rel, absolute in (
            ("base", loose_rtol, float(atol)),
            ("tight", tight_rtol, tight_atol),
        ):
            sol = solve_ivp(
                robertson_rhs,
                (0.0, float(t_end)),
                [1.0, 0.0, 0.0],
                method=method,
                jac=robertson_jacobian,
                rtol=rel,
                atol=absolute,
                dense_output=True,
            )
            if not sol.success or not np.all(np.isfinite(sol.y)):
                raise RuntimeError(f"Development {method} {level} reference failed: {sol.message}")
            key = f"{method}_{level}"
            solutions[key] = sol
            solve_stats[key] = {
                "rtol": rel, "atol": absolute,
                "nfev": int(sol.nfev), "njev": int(sol.njev), "nlu": int(sol.nlu),
            }
    samples = {name: sol.sol(t).T for name, sol in solutions.items()}

    def discrepancy(a, b):
        return float(np.max(np.linalg.norm(samples[a] - samples[b], axis=1)))

    metadata = {
        "source": "development_generated",
        "status": "DEVELOPMENT ONLY - replace with team-confirmed reference for final submission",
        "is_team_confirmed": False,
        "method": "Radau_tight",
        "t_end": float(t_end),
        "positive_output_points": int(n_points),
        "output_grid": "[0] plus geomspace(1e-8, t_end, n_points)",
        "validation_norm": "max over stored t_ref of Euclidean full-state differences",
        "validation": {
            "Radau_refinement_max_diff": discrepancy("Radau_base", "Radau_tight"),
            "BDF_refinement_max_diff": discrepancy("BDF_base", "BDF_tight"),
            "tight_Radau_BDF_max_diff": discrepancy("Radau_tight", "BDF_tight"),
            "base_Radau_BDF_max_diff": discrepancy("Radau_base", "BDF_base"),
        },
        "validation_note": "Independent solver/tolerance comparisons are evidence, not certified error bounds.",
        "requested_tolerance_tightening": 100,
        "effective_rtol_tightening": loose_rtol / tight_rtol,
        "scipy_rtol_floor": scipy_rtol_floor,
        "solver_stats": solve_stats,
        "dependencies": {"numpy": np.__version__, "scipy": scipy.__version__},
        "interpolation": "in memory: tight Radau dense output; reloaded: RHS-based cubic Hermite",
    }
    tight_solution = solutions["Radau_tight"]
    return Reference(t, samples["Radau_tight"], metadata, lambda times: tight_solution.sol(times).T)
