"""Absolute-stability functions and measured Robertson eigenvalue analysis."""

import numpy as np

from .model import robertson_jacobian


def R_euler(z):
    return 1 + np.asarray(z)


def R_rk4(z):
    z = np.asarray(z)
    return 1 + z + z**2 / 2 + z**3 / 6 + z**4 / 24


def R_implicit_euler(z):
    with np.errstate(divide="ignore", invalid="ignore"):
        return 1 / (1 - np.asarray(z))


def reduced_jacobian(t, y):
    """Jacobian for (y1,y2) with y3=1-y1-y2, on the conservation plane."""
    y1, y2 = np.asarray(y, dtype=float)[:2]
    y3 = 1.0 - y1 - y2
    return np.array([
        [-0.04 - 1e4 * y2, 1e4 * (y3 - y2)],
        [0.04 + 1e4 * y2, -1e4 * (y3 - y2) - 6e7 * y2],
    ])


def eigenanalysis(reference, zero_threshold=1e-10):
    """Remove numerical zeros by magnitude, then sort by abs(real part).

    t=0 is excluded: it has two zero eigenvalues. A positive sample is valid
    only when exactly one full-Jacobian eigenvalue is filtered as zero and the
    remaining modes are decaying. Reduced-Jacobian agreement is recorded.
    ee_h_limit uses min(-2*Re(lambda)/abs(lambda)**2) for the two nonzero modes,
    which also covers complex eigenvalues. This is a local frozen-Jacobian
    diagnostic, not a nonlinear-stability guarantee.
    """
    if not np.isfinite(zero_threshold) or zero_threshold <= 0:
        raise ValueError("zero_threshold must be finite and positive.")
    positive = reference.t > 0
    t = reference.t[positive]
    states = reference.Y[positive]
    size = len(t)
    slow = np.full(size, np.nan + 0j, dtype=complex)
    fast = np.full(size, np.nan + 0j, dtype=complex)
    zero = np.full(size, np.nan + 0j, dtype=complex)
    zero_count = np.zeros(size, dtype=int)
    ratio = np.full(size, np.nan)
    h_limit = np.full(size, np.nan)
    valid = np.zeros(size, dtype=bool)
    reduced_slow = np.full(size, np.nan + 0j, dtype=complex)
    reduced_fast = np.full(size, np.nan + 0j, dtype=complex)
    reduced_mismatch = np.full(size, np.nan)
    reduced_agrees = np.zeros(size, dtype=bool)
    for i, (ti, yi) in enumerate(zip(t, states)):
        values = np.linalg.eigvals(robertson_jacobian(ti, yi)).astype(complex)
        zero[i] = values[np.argmin(np.abs(values))]
        is_zero = np.abs(values) < zero_threshold
        zero_count[i] = np.count_nonzero(is_zero)
        reduced = np.linalg.eigvals(reduced_jacobian(ti, yi)).astype(complex)
        reduced = reduced[np.argsort(np.abs(reduced.real))]
        reduced_slow[i], reduced_fast[i] = reduced
        modes = values[~is_zero]
        if zero_count[i] != 1 or len(modes) != 2:
            continue
        modes = modes[np.argsort(np.abs(modes.real))]
        slow[i], fast[i] = modes
        reduced_mismatch[i] = float(np.max(np.abs(modes - reduced)))
        reduced_agrees[i] = np.allclose(modes, reduced, rtol=1e-7, atol=1e-8)
        if np.any(modes.real >= 0) or np.any(np.abs(modes.real) <= zero_threshold):
            continue
        ratio[i] = abs(modes[1].real) / abs(modes[0].real)
        h_limit[i] = float(np.min(-2 * modes.real / np.abs(modes)**2))
        valid[i] = bool(reduced_agrees[i])
    return {
        "t": t,
        "lambda_slow": slow,
        "lambda_fast": fast,
        "stiffness_ratio": ratio,
        "zero_eigenvalue": zero,
        "zero_count": zero_count,
        "valid": valid,
        "ee_h_limit": h_limit,
        "reduced_lambda_slow": reduced_slow,
        "reduced_lambda_fast": reduced_fast,
        "reduced_eigenvalue_mismatch": reduced_mismatch,
        "reduced_agrees": reduced_agrees,
    }


stiffness_analysis = eigenanalysis
