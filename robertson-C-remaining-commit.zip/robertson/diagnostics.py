"""Shared sampled-error, conservation and native-node positivity diagnostics."""

import numpy as np
from scipy.interpolate import CubicHermiteSpline

from .model import robertson_rhs


def _align_to_reference(t, Y, query_times):
    """Cubic Hermite interpolation, evaluating derivatives only where needed.

    Keeping both native endpoints of every queried interval gives exactly the
    same values as constructing the interpolant over the complete trajectory.
    Extra RHS work belongs to diagnostics and is reported separately.
    """
    if len(query_times) == 0:
        return np.empty((0, 3)), 0
    if len(t) == 1:
        if np.any(query_times != t[0]):
            raise ValueError("Cannot interpolate a one-point trajectory.")
        return np.repeat(Y[:1], len(query_times), axis=0), 0
    left = np.clip(np.searchsorted(t, query_times, side="right") - 1, 0, len(t) - 2)
    indices = np.unique(np.concatenate((left, left + 1)))
    slopes = np.asarray([robertson_rhs(t[i], Y[i]) for i in indices])
    aligned = CubicHermiteSpline(t[indices], Y[indices], slopes, extrapolate=False)(query_times)
    # A stored node is already the numerical value; do not add polynomial
    # evaluation roundoff when the output grid hits that node exactly.
    positions = np.searchsorted(t, query_times)
    exact = (positions < len(t)) & (t[np.minimum(positions, len(t)-1)] == query_times)
    aligned[exact] = Y[positions[exact]]
    return aligned, int(len(indices))


# Public entry point shared by sample export and numerical diagnostics.
align_to_reference = _align_to_reference


def error_diagnostics(
    t, Y, reference, accuracy_threshold=1e-4, negativity_tol=1e-12, completed=True
):
    """Compute common diagnostics without extrapolating failed trajectories.

    E_full is the sampled maximum 2-norm error on all reference output times,
    not a continuous-time error bound.  E_cons and positivity use native nodes.
    Incomplete runs receive NaN for E_full/E_40 and may have E_full_partial.
    ``completed=False`` must be passed when a solver fails, even if its last
    attempted step happens to touch t=40.
    """
    t = np.asarray(t, dtype=float)
    Y = np.asarray(Y, dtype=float)
    if t.ndim != 1 or not len(t) or Y.shape != (len(t), 3):
        raise ValueError("Numerical trajectory must have t shape (N,) and Y shape (N,3), N>=1.")
    if not np.all(np.isfinite(t)) or np.any(np.diff(t) <= 0):
        raise ValueError("Numerical times must be finite and strictly increasing.")
    if not np.isfinite(accuracy_threshold) or accuracy_threshold <= 0:
        raise ValueError("accuracy_threshold must be finite and positive.")
    if not np.isfinite(negativity_tol) or negativity_tol < 0:
        raise ValueError("negativity_tol must be finite and nonnegative.")
    finite_rows = np.all(np.isfinite(Y), axis=1)
    first_bad = np.flatnonzero(~finite_rows)
    prefix_len = int(first_bad[0]) if len(first_bad) else len(t)
    finite_values = Y[np.isfinite(Y)]
    y_min = float(np.min(finite_values)) if len(finite_values) else float("nan")
    if np.any(np.isneginf(Y)):
        y_min = float("-inf")
    negative_rows = np.flatnonzero(np.any(Y < -negativity_tol, axis=1))
    first_negative = float(t[negative_rows[0]]) if len(negative_rows) else None
    conservation = float(np.max(np.abs(Y.sum(axis=1) - 1.0))) if np.all(finite_rows) else float("inf")
    full_coverage = bool(
        completed and np.all(finite_rows)
        and t[0] <= reference.t[0] and t[-1] >= reference.t[-1]
    )
    if prefix_len:
        mask = (reference.t >= t[0]) & (reference.t <= t[prefix_len - 1])
        query_times = reference.t[mask]
        aligned, interpolation_calls = _align_to_reference(t[:prefix_len], Y[:prefix_len], query_times)
        errors = np.linalg.norm(aligned - reference.Y[mask], axis=1)
        partial_error = float(np.max(errors)) if len(errors) else float("nan")
    else:
        mask = np.zeros(len(reference.t), dtype=bool)
        query_times = np.empty(0)
        errors = np.empty(0)
        interpolation_calls = 0
        partial_error = float("nan")
    full_coverage = full_coverage and len(query_times) == len(reference.t)
    E_full = partial_error if full_coverage else float("nan")
    E_40 = float("nan")
    # The name E_40 is intentionally literal, even for short test references.
    final_at_40 = np.isclose(reference.t[-1], 40.0, rtol=0, atol=1e-12)
    if full_coverage and final_at_40 and len(errors):
        E_40 = float(errors[-1])
    return {
        "E_full": E_full,
        "E_full_partial": partial_error,
        "E_40": E_40,
        "E_cons": conservation,
        "y_min": y_min,
        "first_negative_time": first_negative,
        "accurate_flag": bool(full_coverage and np.isfinite(E_full) and E_full <= accuracy_threshold),
        "nonnegative_flag": bool(np.all(finite_rows) and y_min >= -negativity_tol),
        "completed": bool(full_coverage),
        "comparison_points": int(len(query_times)),
        "interpolation_rhs_evals": interpolation_calls,
        "accuracy_threshold": float(accuracy_threshold),
        "negativity_tol": float(negativity_tol),
    }
