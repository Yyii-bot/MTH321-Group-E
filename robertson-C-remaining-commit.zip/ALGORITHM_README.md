# Topic 3 Robertson Chemical Kinetics

**Algorithm Implementation / 数值方法与可复现实验**

这是算法实现负责人的交付项目：EE、RK4、Implicit Euler + Newton、自适应步长、稳定性与刚性分析、误差诊断、参数扫描和成本比较。中文说明配合英文代码、图表及数据字段，方便组内协作和课程汇报。

## 先看这一点

当前提供的课程附件没有团队已经确认的 `t_ref / y_ref` 数值文件。因此，仓库附带的运行结果全部标注 **DEVELOPMENT ONLY**：程序临时构建 Radau/BDF 参考解并收紧容差交叉检查，用于验证实现。它们不冒充团队最终参考结果。

拿到团队参考文件后，使用 `--reference` 重跑，所有正式对比即可使用同一份数据。课程原始教材和附件未复制进仓库；依据和页码见 [资料对应表](docs/source_map.md)。本仓库不包含替组员编造的 ICS 或最终报告结论。

## 快速运行

建议 Python 3.12。在解压后的项目根目录打开终端：

```bash
python -m venv .venv
```

Windows PowerShell 激活：

```powershell
.venv\Scripts\Activate.ps1
```

macOS / Linux 激活：

```bash
source .venv/bin/activate
```

然后：

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python code/run_all.py
```

根目录的 `python run_all.py` 是同一个入口。参数说明：

```bash
python code/run_all.py --help
python code/run_all.py --reference data/team_reference.npz
python code/run_all.py --config my_config.json
python code/run_all.py --save-trajectories
```

默认会完整运行所有实验，生成 PNG/PDF 图、CSV 表和 NPZ 数值样本。显式方法需要大量小步，预计几分钟，实际耗时取决于电脑。附带结果的实测耗时与版本记录在 [运行摘要](results/development/SUMMARY.md) 和 `results/development/manifest.json`。`requirements-tested.txt` 记录本次验证所用的直接依赖版本。

## 目录

```text
robertson-topic3/
  code/run_all.py             课程约定的一键入口
  run_all.py                  根目录便捷入口
  robertson/
    model.py                  Robertson RHS / analytic Jacobian
    newton.py                 通用 Newton 迭代与线性求解
    solvers.py                EE / RK4 / IE 固定步长求解器
    adaptive.py               RK4 / IE step doubling
    reference.py              团队参考读写、开发 oracle
    diagnostics.py            统一对齐与误差/守恒/非负性指标
    stability.py              R(z)、full/reduced eigenanalysis
    config.py                 默认参数与实验网格
    experiments.py            实验编排、图表、可追溯记录
  tests/                      数学正确性与失败边界测试
  data/                       参考解 NPZ 与格式说明
  results/development/        本次开发验证数据、表、摘要
  figures/development/        本次开发验证图表
  docs/                       方法说明、源资料映射、AI使用记录模板
  .github/workflows/tests.yml GitHub push / PR 自动测试
```

## 模型

```text
y1' = -0.04*y1 + 1e4*y2*y3
y2' =  0.04*y1 - 1e4*y2*y3 - 3e7*y2^2
y3' =  3e7*y2^2
y(0) = [1, 0, 0],  t in [0, 40]
y1 + y2 + y3 = 1
```

`3e7*y2^2` 不额外乘 2。完整 Jacobian 的 `df2/dy2` 和 `df3/dy2` 中才出现求导产生的 `6e7*y2`。所有模型数值来自已读取的 Topic 3 分工文件及课程 scaffold；未把教材的终值或刚性比写进算法。

## 已实现的实验

| 实验 | 实现方式 | 自动输出 |
|---|---|---|
| Fixed-step convergence | 三种方法各至少4个连续减半 h；同一参考采样网格 | `convergence.csv`、error-vs-h 图 |
| Absolute stability | EE/RK4/IE 的 `abs(R(z))<=1` 与边界 | 三张 stability 图 |
| Eigenanalysis | 沿参考轨迹去除结构零模态；按实部大小排序；与 reduced Jacobian 交叉核验 | `eigenanalysis.csv/.npz`、两非零特征值与刚性比图 |
| EE failure sweep | 从 `8e-4,6e-4,5e-4,4e-4` 开始；检测到分类变化时加中点 | `ee_failure.csv`、临界行为图 |
| Diagnostics | 分开记录守恒、非负、准确性、终值误差 | `diagnostics.csv`、diagnostics 图 |
| Matched error | 使用实测误差匹配 EE/IE，必要时补跑 IE | `matched_error.csv` |
| Newton tolerance | 固定 `h=0.1`，tol 从 `1e-4` 到 `1e-12` | `newton_tolerance.csv`、误差平台图 |
| Adaptive | RK4 主方案 + 课程 scaffold 的 IE 扩展，接受两半步解 | `adaptive.csv`、h(t)、local tol vs actual error |
| Cost vs accuracy | 在相同误差上限下筛选已测试的可用结果 | `cost_vs_accuracy.csv`、error-vs-cost 图 |

所有行都有 `run_id`，对应 `results/<kind>/runs/` 中的参数、统计和采样解。没有满足目标的实测算例时，成本表明确写 `target_met=False`，不会编造结果。相近误差配对的默认允许比值为 `1.15`，表中报告实际比值。

## 统一接口

```python
from robertson.solvers import solve_fixed
from robertson.adaptive import solve_adaptive

t, Y, stats = solve_fixed("IE", 0, 40, [1, 0, 0], 0.01,
                          options={"newton_tol": 1e-12, "newton_maxiter": 30})
t, Y, stats = solve_adaptive("RK4", 0, 40, [1, 0, 0],
                             h0=1e-3, tol=1e-6)
```

`Y.shape == (len(t), 3)`。返回完整已接受轨迹；末步缩短到终点。失败时保留有效前缀和具体 `failure / failure_time`，不把失败步当作成功结果。负浓度不会被裁剪或重新归一化。

`stats` 记录实际 RHS/Jacobian/linear solve 次数、Newton updates、接受/拒绝步数、失败状态与积分时间。IE 的每步 Newton 最终残差和迭代数可查。adaptive 的 Newton histories 覆盖所有尝试，包括 coarse、half、fine 和拒步；`steps` 指接受的宏步。导出时长历史数组压缩为 `_history.npz`，JSON 保留参数、标量统计和对应文件名。

## 误差、稳定性和成本口径

- `E_full`：在共同 `t_ref` 上，三分量误差的 Euclidean norm 的最大值。它是采样误差，不是连续时间误差上界。
- `E_40`：三分量在 40 的 2-norm 误差；`y2_40` 单独记录第二分量。
- `E_cons`：全部已接受原生节点上 `max(abs(sum(Y)-1))`。
- `y_min`：全部已接受原生节点和分量的最小值，含初值，因此非负的正常算例通常为 0。
- `nonnegative_flag`：允许配置的 `1e-12` 舍入级负值；同时保留真实 `y_min`。
- `accurate_flag`：完成全程且 `E_full <= accuracy_threshold`；默认阈值 `1e-5` 是可调实验选择。
- `stable`：完成全程且无 solver failure、状态绝对值不超过配置限值，同时原生节点 `y2` 总变差与 reference 的比值不超过配置限值。默认限值分别为 2 与 10，用来识别明显增长及伪振荡。它是明确可复现的经验分类，不是非线性稳定性证明。

未完成的 run 的 `E_full/E_40` 在 CSV/JSON 留空；`E_full_partial` 只描述终止前覆盖的时间点，不能与完整 run 混比。图中的 `h*lambda` 只是 local frozen-Jacobian diagnostic，不能代替真实步长扫描。

所有方法共用 RHS-based cubic Hermite 对齐规则，避免线性插值限制 RK4 的观测阶数。这里使用数值轨迹端点值及模型导数，数值误差仍由实测 convergence 检验；团队参考的 400 个点不会被任意线性插值后冒充高精度真值。`reference.evaluate` 用于额外查询时必须注意采样/插值精度，主要 `E_full` 直接比较文件中共同网格的原始参考值。

积分成本包括全部尝试中的真实调用，含 adaptive 拒步；不包括参考构建、诊断插值、图表和文件保存。插值调用数另列。RHS 次数不能代表 IE 的全部工作，须一起查看 `jac_evals`、`linear_solves`、`newton_iters` 和积分 wall time。计时结果随机器变化。

## 自适应和 Newton 的解释边界

RK4 的误差估计为 `norm(y_half2-y_full, inf)/15`，IE 为同一差值除以 1。控制器使用阶数 `p` 对应的指数 `1/(p+1)`，有 safety factor、增长/缩小限制、最小/最大步长和拒步保护。

local tolerance 不自动保证 `E_full <= tol`。程序会报告实际误差和拒步数，显式 RK4 在 Robertson 上仍受稳定性约束。Newton tolerance 控制的是隐式离散方程残差；固定 h 时继续收紧，时间离散误差通常会形成平台。具体证据以本次生成的数据为准。

## 接入团队参考解

格式详见 [data/README.md](data/README.md)。文件至少有 `t_ref`、`y_ref`，必须覆盖 0 到 40、初值正确、至少200个正时间输出点；推荐 `[0] + geomspace(1e-8,40,N)`。统一使用团队提供的输出网格。

```bash
python code/run_all.py --reference data/team_reference.npz
```

外部数据在 `results/team/` 和 `figures/team/` 输出，标签为 `TEAM-SUPPLIED REFERENCE`。这仅说明数据来源，并不自动证明参考精度；团队仍需保留独立求解、容差收紧和有效数字核验记录。显式传入本仓库 development 文件时，仍保留 development 标签。

## 修改参数

默认参数集中在 `robertson/config.py`，也可使用 JSON 局部覆盖，例如：

```json
{
  "accuracy_threshold": 0.00001,
  "solver_options": {"newton_tol": 1e-12},
  "newton_sweep_h": 0.05
}
```

每次实际参数会保存为 `config_used.json`，manifest 同时保存参数和参考文件 SHA-256、参考来源、运行版本和耗时。保留收敛研究中至少4个连续减半步长；改变数值策略后重跑测试和完整实验。

## 上传 GitHub

解压 ZIP，将项目文件夹内的内容放到你的 GitHub 仓库根目录。不要只把整个 ZIP 当成源码提交。也可以在已解压的项目根目录使用 Git：

```bash
git init
git add .
git commit -m "Implement Robertson Topic 3 solvers and experiments"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

把 `YOUR_GITHUB_REPOSITORY_URL` 换成你创建的空仓库地址。如果已有组内仓库，按 PM 的目录安排合并这些文件并保留既有 Git 历史。首次 push 后自动测试会运行；完整数值实验由你在本地执行。

`.gitignore` 排除了虚拟环境、缓存和可选的大体积原生轨迹，保留本次示例图表及摘要便于审阅。所有图和表都可以用统一入口重新生成。

## 交给组员的内容

- Validation：`data/` 接口、所有误差/失败/计数字段和 tests。
- Math：完整与 reduced Jacobian 计算、两非零模态、稳定域与 sweep 实测证据。
- Visualization：`figures/` 下的 PNG/PDF，以及 `results/` 中可追溯的 CSV/NPZ。
- PM：运行命令、依赖、测试结果和每次 config/manifest。

算法说明与验收细节见 [implementation_notes.md](docs/implementation_notes.md)。实际使用 AI 的修改与验证过程应填入 [AI 使用记录模板](docs/ai_usage_log.md)，个人贡献由本人如实填写。
