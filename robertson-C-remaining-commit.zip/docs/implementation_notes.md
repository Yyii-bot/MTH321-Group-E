# 实现与实验说明

本项目交付 Algorithm Implementation 的代码、可复现实验和交接材料。任务来源和页码见 [source_map.md](source_map.md)。报告中的理论推导、团队 reference 的最终认定、个人贡献说明仍需相应成员核对。下文解释实现选择，不预先宣称某种方法获胜。

## 1. 模型与接口

Robertson 模型为

\[
\begin{aligned}
y_1'&=-0.04y_1+10^4y_2y_3,\\
y_2'&=0.04y_1-10^4y_2y_3-3\times10^7y_2^2,\\
y_3'&=3\times10^7y_2^2,
\end{aligned}
\qquad y(0)=(1,0,0)^T,\quad 0\le t\le40.
\]

三个导数相加为零，因此总浓度应保持 1。代码直接计算三个分量，没有事后归一化或把负数截成零；这种修改会掩盖方法原本的误差和非物理解。[S2，第 1–3 页；S5，Model 注释]

固定步长入口是 `solve_fixed(method, t0, tf, y0, h, options=None)`；`method` 为 `EE`、`RK4` 或 `IE`。返回 `t, Y, stats`，其中 `Y.shape == (len(t), 3)`。最后一步缩短以落在终点，不把越过终点的状态当作终点解。有限的负浓度保留在轨迹中供独立诊断；Newton 失败、非有限数或超过 blow-up 阈值时停止并返回已接受的轨迹及失败原因。[S1，第 1–3 页]

`stats["converged"]` 表示数值求解流程成功到达指定终点。它不等于精度达标，也不是完整非线性系统的稳定性证明。配置错误抛出 `ValueError`，实验中出现的数值失败使用 `failure`、`failure_time` 明确记录。

## 2. 三种基本方法与 Newton

Explicit Euler：

\[
y_{n+1}=y_n+h f(t_n,y_n).
\]

Classical RK4：

\[
\begin{aligned}
k_1&=f(t_n,y_n),& k_2&=f(t_n+h/2,y_n+hk_1/2),\\
k_3&=f(t_n+h/2,y_n+hk_2/2),& k_4&=f(t_n+h,y_n+hk_3),\\
y_{n+1}&=y_n+\tfrac h6(k_1+2k_2+2k_3+k_4).
\end{aligned}
\]

Implicit Euler 解离散非线性方程

\[
F(z)=z-y_n-hf(t_{n+1},z)=0,\qquad J_F(z)=I-hJ_f(t_{n+1},z).
\]

Newton 以 `z = y_n` 为初始猜测，求解 `J_F delta = -F`，再更新 `z += damping * delta`。使用线性求解，不显式计算矩阵逆。停止标准为残差无穷范数不超过 `newton_tol`；保留每次非线性求解的迭代数和最终残差。达到最大迭代数仍不满足标准时，不接受该失败状态。[S1，第 2–3 页；S2，第 3 页；S5，Newton scaffold]

Newton 误差与时间离散误差是两件事：更多 Newton 迭代让 `F(z)=0` 解得更准确，减小时间步长才会改善离散方法对连续 ODE 的近似。过松的 Newton tolerance 甚至可能使初值猜测在未更新时就被判定残差足够小。因此 tolerance sweep 应如实保留差结果。演示材料用 `y'=-y²` 说明这一区别，本代码的 Robertson 结果不使用该例的数值作为答案。[S7，第 1 张幻灯片]

## 3. 参考解、对齐和误差

个人任务书的前提是团队已经确认统一的 `t_ref, y_ref`。本次可读取的材料未包含该团队数据，仓库提供明确标记为 **development reference** 的参考生成途径，用于使代码、图表和测试可运行；它不能冒充团队已经审核的 reference。正式整合时应导入团队数据，并检查其误差水平是否足以支持所报告的有效数字。[S1，第 1–2 页；S2，第 3 页]

所有方法通过统一 `align_to_reference` 将数值轨迹对齐到共同的 `t_ref`，再直接与文件中的参考值比较。对齐使用数值状态和模型导数的 cubic Hermite 插值；`reference.evaluate(t)` 仅用于额外查询，加载离散参考文件后，额外查询的精度受参考插值限制。参考解误差、插值误差和浮点舍入都可能形成 convergence 图的误差平台；平台附近的斜率不能用来否定方法理论阶数。短时间测试验证进入渐近区间后的 EE/IE 一阶和 RK4 四阶；完整区间实验检验 Robertson 任务本身，二者目的不同。

统一误差采用全状态欧氏范数：

\[
E_{\rm full}=\max_i\|Y_i-y_{\rm ref}(t_i)\|_2,\quad
E_{40}=\|y_{\rm num}(40)-y_{\rm ref}(40)\|_2,
\]
\[
E_{\rm cons}=\max_i\left|\sum_jY_{ij}-1\right|,\qquad
y_{\min}=\min_{i,j}Y_{ij}.
\]

`E_full` 是共同参考时间点上的最大误差，不是对连续时间的严格上界。未完成全程的轨迹将 `E_full/E_40` 标记为缺失；`E_full_partial` 单独描述已覆盖区间。`accurate`、`nonnegative` 和守恒误差分别记录：总浓度保持 1 并不能保证三个分量正确，也不能保证它们均非负。[S1，第 5 页]

## 4. 收敛性、稳定域与 eigenanalysis

收敛实验使用至少四个连续减半的步长，逐对计算

\[
p_{\rm obs}=\log_2(E_h/E_{h/2}).
\]

预期 EE 和 IE 为 1 阶、RK4 为 4 阶，但只有在稳定且进入渐近区间、参考误差尚未主导时才应观察到这些阶数。[S1，第 3 页；S2，第 3 页]

三种稳定函数为

\[
R_{EE}(z)=1+z,\quad
R_{RK4}(z)=1+z+z^2/2+z^3/6+z^4/24,\quad
R_{IE}(z)=\frac1{1-z}.
\]

稳定域图画 `|R(z)| <= 1` 的区域。把沿 reference 得到的 `h lambda(t)` 叠加其上，只能进行 **local frozen-Jacobian diagnostic**。这不是非线性 Robertson 方程的全局稳定性证明；还需步长扫描检验实际行为。资料中约 `5.9e-4` 的 EE 步长限制是局部估计，不作为硬编码的成功/失败分界。[S1，第 4–5 页；S2，第 2 页；S4，第 1 页]

完整 Jacobian 因守恒律具有 structural zero eigenvalue。不能按 `eig` 返回顺序删除第一个值，也不能把零值用于 stiffness ratio 的分母。使用可配置阈值辨认零值，同时用 `y3 = 1-y1-y2` 的二维 reduced Jacobian 核对非零模态；在 `t=0` 有两个零特征值，不计算 stiffness ratio。非零模态按实部绝对值标记 slow/fast，

\[
S(t)=\frac{\max_{\lambda\ne0}|\Re\lambda(t)|}
{\min_{\lambda\ne0}|\Re\lambda(t)|}.
\]

如果阈值意外筛掉物理慢模态，应暴露该诊断，不能静默制造一个 ratio。[S1，第 4 页；S2，第 1–2 页]

## 5. 实验应如何解读

| 实验 | 改变的量 | 必须保留的证据 |
|---|---|---|
| EE failure sweep | 稳定限制附近的 `h`，包括 `8e-4, 6e-4, 5e-4, 4e-4` | 失败/首次负值时间、完成状态、`E_full`、守恒误差；没有爆炸不等于准确 |
| Matched-error | EE/IE 的步长候选 | 在误差接近且完整完成的 run 间比较步数、RHS、Newton；如果候选未匹配要如实说明 |
| Newton tolerance sweep | 固定 IE 的 `h`，改变 Newton tolerance | `y2(40)`、`E_full`、守恒误差、迭代数、失败状态；误差平台是否出现由结果决定 |
| Adaptive | local tolerance、方法 | 实际步长变化、接受/拒绝次数、reference 误差；local tolerance 不等于 global error 保证 |
| Cost-vs-accuracy | 已完成 run 的误差与工作量 | 完整记录误差和 RHS/Jacobian/线性求解/Newton 成本，分清不同口径 |

这些实验直接对应 S1 第 5–7 页。所有图表数值应由代码产生，不把任务书中的 sanity-check 数字写进算法或结果文件。

## 6. 自适应控制与计数口径

Step doubling 从同一个起点做一个 `h` 步得到 `y_full`，再做两个 `h/2` 步得到 `y_half2`。采用

\[
\operatorname{err}=\|y_{\rm half2}-y_{\rm full}\|_\infty/(2^p-1),
\]

其中 RK4 的 `p=4`、IE 的 `p=1`。若满足 tolerance 就接受 `y_half2`，否则状态和时间不前进并缩短步长。控制器使用 safety factor 和增长/缩小限制，指数为 `1/(p+1)`；同时受 `h_min`、`h_max` 和终点限制。RK4 step doubling 对应个人任务书，IE step doubling 补齐教师 scaffold 的 deep-work hook。[S1，第 6 页；S5，adaptive scaffold]

计数在实际函数调用处增加。完整的固定步长 EE 每步 1 次 RHS，RK4 每步 4 次 RHS；完整 RK4 doubling trial 为 12 次 RHS。被拒绝 trial 也计入成本；若失败提前终止 trial，则只计已经执行的调用。Newton 残差检查也需要 RHS，不能用 `steps * 常数` 替代它的真实成本。自适应 IE 的 Newton 历史包含所有基础子步和被拒绝 trial，而不是只有宏观接受步。

`runtime_seconds` 是一次 solver 的实际墙钟时间；硬件、负载和运行环境均会影响它。RHS 数不包含 Jacobian/线性求解开销，因此不能只用 RHS 数宣称 implicit 方法总成本更低。完整实验还含 reference、分析和绘图开销，与单个 solver 的时间应分开解释。[S1，第 7 页]

## 7. 验证与团队交接

测试覆盖：初始导数、质量守恒的代数恒等式、解析 Jacobian 的独立有限差分核对、full/reduced eigenvalues 一致、三个方法对 SciPy oracle 的短时间轨迹误差、四档步长的阶数、Newton 失败、EE 大步长失败、终点截步、adaptive 拒步成本、未完成轨迹不伪造 `E_40`。这些测试支持实现正确性，不代替团队对全部实验结果的审核。

正式合并时，请团队核对统一 reference、参数口径、图注、误差匹配是否成功及报告有效数字。报告/幻灯片成员可使用生成图表，数学成员需检查推导，验证成员需认定最终 reference。Algorithm 成员应能解释和修改关键代码，保留真实 Git 提交记录。[S3，第 2–3 页；S4，第 4 页]

## 8. AI Transparency Log 与 ICS 待填写模板

本交付由 Codex 协助生成代码、测试和说明。以下模板留给组员根据自己实际阅读、修改和验证情况填写；它不是已完成的个人贡献声明。

| 日期 | 使用的 AI 工具/版本 | 请求摘要 | 实际采用的输出 | 自己修改了什么及原因 | 自己执行的验证与证据 |
|---|---|---|---|---|---|
| 待填写 | 待填写 | 待填写 | 待填写 | 待填写 | 待填写 |

ICS 要点：本人具体完成的工作；与其他成员的接口；能够解释的算法；独立检查/修改的地方；尚未亲自验证的内容。请勿将 AI 自动生成、尚未理解的内容写成独立完成。[S3，第 3 页；S4，第 4 页]
