# 资料依据与范围

本文件说明哪些内容来自本次实际读取的用户附件，哪些属于代码实现选择。页码按 PDF 的物理页码计。交付不打包完整课程原教材。

| 编号 | 实际读取的材料 | 用途与位置 |
|---|---|---|
| S1 | 《Robertson Problem — 组员 2 任务书：代码实现与数值实验（直白执行版）》 | 第 1–3 页：职责、统一接口、EE/RK4/IE+Newton、convergence；第 4 页：稳定域、eigenanalysis；第 5 页：failure sweep、diagnostics、matched-error；第 6 页：Newton tolerance、自适应；第 7 页：cost 和图表；第 8–9 页：run_all、README、交付验收 |
| S2 | 《Topic 3：Robertson Chemical Kinetics — 基于 Role Cards 的 Project 1 任务拆解与四周执行安排》 | 第 1–3 页：完整模型、初值、守恒、Jacobian、结构零值、reduced Jacobian、区间 `[0,40]`、reference 与误差要求；第 4–6 页：图表、实验顺序和常见风险 |
| S3 | 《Role Description Cards — Five-Person Team》 | 第 2 页：Algorithm Implementation 应实现 Euler/RK4/implicit+Newton/adaptive，保持 run_all；第 3 页：团队 reference、边界测试、ICS 真实性；第 4 页：并行协作 |
| S4 | 《Project 1 Brief — Numerical Solution of ODE Initial Value Problems》 | 第 1–2 页：三种方法、local frozen-Jacobian 限定、adaptive、验证、code zip 和 README；第 3 页：Topic 3 范围；第 4 页：可复现、解释代码、AI transparency |
| S5 | `implicit_euler_skeleton.py` | Model 注释与 TASK 1/2：模型/Jacobian；TASK 3 与 Newton harness：残差、Jacobian、线性求解、收敛；adaptive deep-work hook：IE step doubling；main TASK 4：独立 oracle 和终值比较 |
| S6 | `rk4_stability_region.py` | 三种 stability function、复平面区域绘制、`plot_system_eigenvalues` 和 local frozen-Jacobian 限定；将模板中的 logistic 演示替换为 Robertson 轨迹 |
| S7 | 《Implicit Euler and Newton: a worked example》单页演示材料 | 第 1 张幻灯片：用 `y'=-y²` 区分 Newton error 与 time discretization error；仅解释概念，不替代 Robertson 实验 |

## 本次资料缺口

对应原文件名：S1 `组员2_代码实现与数值实验任务书_直白执行版.pdf`；S2 `Topic3_Robertson_Role_Cards_Task_Breakdown(1).pdf`；S3 `role_cards(1).pdf`；S4 `ODE_IVP_Project_Brief(1).pdf`；S7 `implicit_euler_newton_example_en.pptx`。

对话提到的 `problem_pack(1).pdf` 原始附件本次未能取回，因此不声称已经逐页核验该文件。Robertson 模型、区间、结构零特征值和角色实验要求已从实际读取的 S1、S2、S4、S5 交叉核对。团队正式提交前，若 Problem Pack 有额外细则，应补充核对。

S1 明确写着团队 reference 已经准备好，但本次可访问材料未包含该参考数据。仓库的 development reference 仅服务于开发和可复现演示；团队提供自己的 `t_ref, y_ref` 后应替换并重新生成正式结果，不把生成数据的角色归给用户或其他组员。

## 实现选择与来源的边界

以下是为了使交付可运行、可审查而选择的实现方式，并非宣称原文件强制规定的唯一做法：Python 包结构、CSV/JSON 等输出格式、可配置故障阈值、controller safety factor、独立单元测试的时间窗口、reference 数据的加载接口、图像样式。README 和配置文件给出当前实际值。

资料中的约 `5.9e-4` 稳定性估计、stiffness 数量级和示例终值只用于概念检查。代码应从状态、Jacobian、reference 和实验轨迹计算数值，不能回填预期答案。任何结果结论都以本次生成的表格和检查结果为准。
