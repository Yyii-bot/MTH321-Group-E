"""Convenience entry point, equivalent to python code/run_all.py."""

from robertson.experiments import main

if __name__ == "__main__":
    raise SystemExit(main())
